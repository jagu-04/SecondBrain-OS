
from fastapi import FastAPI, UploadFile
from pydantic import BaseModel
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = FastAPI(title="SecondBrain OS Elite")

documents = []
vectorizer = TfidfVectorizer()

class Query(BaseModel):
    question: str

@app.get("/")
def root():
    return {"status": "SecondBrain OS Elite running"}

@app.post("/upload")
async def upload_file(file: UploadFile):
    text = (await file.read()).decode("utf-8", errors="ignore")
    documents.append(text)
    return {"documents_indexed": len(documents)}

@app.post("/query")
def query_brain(q: Query):
    if not documents:
        return {"answer": "No knowledge indexed yet."}

    vectors = vectorizer.fit_transform(documents + [q.question])
    sims = cosine_similarity(vectors[-1], vectors[:-1])[0]
    idx = int(np.argmax(sims))

    context = documents[idx][:400]

    # LLM-ready response (drop-in Gemini/OpenAI later)
    answer = f"""Context used:
    {context}

    Final Answer:
    This response is generated using retrieved memory. 
    (LLM hook ready for production)
    """

    return {
        "question": q.question,
        "answer": answer,
        "similarity_score": float(sims[idx])
    }
