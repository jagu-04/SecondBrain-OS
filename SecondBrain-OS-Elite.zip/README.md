
# SecondBrain OS Elite 🧠

SecondBrain OS Elite is a **winner-grade AI knowledge system**
built for **Missing Amps Winter Classic 2025**.

## 🔥 Elite Features
- Semantic memory indexing
- Vector similarity retrieval
- LLM-ready RAG architecture
- Clean demo interface
- Offline-friendly, privacy-first

## 🧠 Architecture
Upload → Vectorize → Retrieve → (LLM Generate)

## 🛠 Tech Stack
- Backend: FastAPI
- AI/ML: TF-IDF, cosine similarity
- Frontend: HTML + JS
- LLM: Plug-and-play (Gemini / OpenAI / LLaMA)

## ▶️ Run
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```
Open `frontend/index.html`.

## 🏆 Hackathon
Built for Missing Amps Winter Classic – Winter 2025
